/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.ac by autoheader.  */

/* Version number of package */
#define VERSION "3.1.1"

/* Define to 'static' if no test programs will be compiled. */
#define __STATIC static
   
